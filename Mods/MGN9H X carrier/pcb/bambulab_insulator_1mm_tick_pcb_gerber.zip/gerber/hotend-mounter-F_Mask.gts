G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.5+1*
G04 #@! TF.CreationDate,2026-07-11T21:34:33+09:00*
G04 #@! TF.ProjectId,hotend-mounter,686f7465-6e64-42d6-9d6f-756e7465722e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.5+1) date 2026-07-11 21:34:33*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
